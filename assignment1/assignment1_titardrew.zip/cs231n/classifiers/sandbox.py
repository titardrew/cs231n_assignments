import numpy as np
import itertools as it
for (a, b) in it.product([1, 2, 3], [1, 3, 5]):
  print(a, b)
